:mod:`apscheduler.jobstores.shelve_store`
=========================================

.. automodule:: apscheduler.jobstores.shelve_store

Module Contents
---------------

.. autoclass:: ShelveJobStore
    :members:
